/*******************************************************************************
 ************************************ bb.h *************************************
 *******************************************************************************
 *                          U N C L A S S I F I E D
 *******************************************************************************
 *******************************************************************************
 *
 * Module Name  :  $Id: bb.h,v 1.1 2021/10/10 15:36:13 joe Exp joe $
 * Programmer   :  Joe L
 * Original Date:  23AUG20
 *
 * -----------------------------------------------------------------------------
 *
 *                    M O D U L E   D E S C R I P T I O N:
 *
 *           FOR READABILITY in vi, GVim, etc.   :set ts:4 OR ts=4
 *
 * Bitbuster program main include file.
 *
 * -----------------------------------------------------------------------------
 *
 *                       R E V I S I O N   H I S T O R Y:
 *
 * $Log: bb.h,v $
 * Revision 1.1  2021/10/10 15:36:13  joe
 * Initial revision
 *
 *
 ******************************************************************************/

#ifndef _BB_H_INCLUDED_

/* ---------------------------- SYSTEM INCLUDES ----------------------------- */
#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---------------------------- PROGRAM INCLUDES ---------------------------- */
#include "../pro/bb.p"				/* Function prototypes for Main helpers */

/* ------------------------------ DEFINITIONS ------------------------------- */

/* -------------------------- FUNCTION RETURN FLAGS ------------------------- */
#define F_DIE fprintf(stderr, "Fatal Error: Abort\n");exit(EXIT_FAILURE);
#define F_FAIL -1
#define F_OK 0

/* -------------------------------- BOOLEANS ----------------------------------
 - In C, true is any nonzero value ... including negatives, and false is 0
 - but, by convention, successful subroutines return a 0 upon completion
 - and strings have a NULL termination of "\0"
 ---------------------------------------------------------------------------- */
#define B_FALSE 0
#define B_TRUE 1

/* --------------------------- MACROS AND GLOBALS -----------------------------
 - Variables that have file scope are global
 ---------------------------------------------------------------------------- */

#define _BB_H_INCLUDED_
#endif	/* _BB_H_INCLUDED_ */

/*******************************************************************************
 *******************************************************************************
 *                          U N C L A S S I F I E D
 *******************************************************************************
 ************************************ bb.h *************************************
 ******************************************************************************/

