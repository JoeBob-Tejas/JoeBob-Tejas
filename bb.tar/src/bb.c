/*******************************************************************************
 ************************************ bb.c *************************************
 *******************************************************************************
 *                          U N C L A S S I F I E D
 *******************************************************************************
 *******************************************************************************
 *
 * Module Name  :  $Id: bb.c,v 1.1 2021/10/10 15:44:06 joe Exp joe $
 * Programmer   :  Joe L
 * Original Date:  23AUG20
 *
 * -----------------------------------------------------------------------------
 *
 *                    M O D U L E   D E S C R I P T I O N:
 *
 *           FOR READABILITY in vi, GVim, etc.   :set ts:4 OR ts=4
 *
 * Bitbuser (bb) decodes TPMS IDs.
 *
 * -----------------------------------------------------------------------------
 *
 *                       R E V I S I O N   H I S T O R Y:
 *
 * $Log: bb.c,v $
 * Revision 1.1  2021/10/10 15:44:06  joe
 * Initial revision
 *
 *
 ******************************************************************************/

#define _GNU_SOURCE
#define MAX 140
#include "../inc/bb.h"

/* -------------------------------------------------------------------------- */
int main(argc, argv, arge)
int argc;					/* Number of varargs passed in */ 
char **argv, **arge;		/* Varargs and env variables */
{
	char name[37] = "Ulysses Group Bit Buster program - bb";
	char version[22] = "Rev 2.7 - August 2020";
	char filename[18] = "../dat/catch4.txt";
	FILE *fp;
	int i=0;			/* counter for loop index */
	int lc=4;			/* number of lines in file */
	char *buf = NULL;
	ssize_t line_size = 0;
	size_t line_buf_size = 0;
	char outstr[65] = "\0";
	int j=0;			/* counter for loop index */
	int offset = 62;	/* offset into line for data */
	/* int offset = 82;	 offset into line for data */
	char hexstr[65] = "\0";
	int k=0;			/* counter for loop index */
	int index=0;		/* counter for loop index */

	printf("%s\n", name);
	printf("%s\n", version);
	printf("\n");

	fp = fopen(filename, "r");
	if ((fp = fopen(filename, "r")) == NULL)
	{
		printf("bb: can't open %s\n", filename);
		return F_FAIL;
	}

	/* get 4 lines of data */
	for (i = 0; i < lc; i += 1)
	{
		/* get line of data */
		line_size = getline(&buf, &line_buf_size, fp);

		/* parse the string */
		for (j = 0; j < 64; j += 1)
		{
			outstr[j] = buf[j+offset];
		}
		outstr[64] = '\0';

		/* convert the string */
/*		k = 0;
		for (j = 0; j < 64; j += 1)
		{
			sprintf((char*)(hexstr, "%02X", outstr);
			k+=2;
		}
		hexstr[64] = '\0';
*/
			sprintf((char*)(hexstr), "%02X", outstr);

		/* YOU ARE HERE */
		printf("%s \n", outstr);
		printf("%s \n", hexstr);
	}


	free(buf);
	fclose(fp);

	return 0;
}

/*******************************************************************************
 *******************************************************************************
 *                          U N C L A S S I F I E D
 *******************************************************************************
 ************************************ bb.c *************************************
 ******************************************************************************/

